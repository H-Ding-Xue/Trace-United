package main.traceUnited;

import main.traceUnited.boundary.*;
import main.traceUnited.controller.UserLoginController;
import main.traceUnited.entity.User;

public class TraceUnited {
	public static void main(String[] args) {
		UserLoginUI userLoginUI = new UserLoginUI();
	}
}
