module traceUnited {
	requires java.desktop;
	requires java.sql;
	requires junit;
	requires jcalendar;
	
	exports test.traceUnited.boundaryTest;
}